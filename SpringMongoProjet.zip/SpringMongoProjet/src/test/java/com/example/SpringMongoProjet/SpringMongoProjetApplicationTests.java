package com.example.SpringMongoProjet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongoProjetApplicationTests {

	@Test
	void contextLoads() {
	}

}
