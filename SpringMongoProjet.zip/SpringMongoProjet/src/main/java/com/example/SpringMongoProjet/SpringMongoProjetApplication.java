package com.example.SpringMongoProjet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMongoProjetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMongoProjetApplication.class, args);
	}

}
